## ---- include = FALSE---------------------------------------------------------
library(tstodfpkg)
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ---- fig.width = 7, fig.height = 5-------------------------------------------
data(synth_gap)
plot(synth_gap, main = "Synthetic Sales Trend", xlab = "Time", ylab = "Sales", type = "l")

## -----------------------------------------------------------------------------
df <- ts_to_df(synth_gap, name = "Sales")
library(dplyr)
sales_summary <- df %>% group_by(Period) %>% summarise(Avg_Sales = mean(Sales))
print(sales_summary)

## ---- fig.width = 7, fig.height = 5-------------------------------------------
library(ggplot2)

ggplot(df, aes(x = Year, y = Sales, color = Period)) + 
  geom_line() + 
  #facet_wrap(~ Year, ncol = 4) + 
  theme_minimal() + 
  theme(legend.position = "top") + 
  labs(title = "Quarterly Sales Over time")

